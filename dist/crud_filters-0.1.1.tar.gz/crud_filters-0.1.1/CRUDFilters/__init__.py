# -*- coding: utf-8 -*-
"""
View and Model base classes used to control access permissions for CRUD requests.
"""
__version__ = '0.1'